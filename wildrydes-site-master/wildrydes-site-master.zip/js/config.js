window._config = {
    cognito: {
        userPoolId: 'us-east-1_qCtBceIuU',
        userPoolClientId: 'mnt4dtoggj7dotvhhbogfum0a',
        region: 'us-east-1'
    },
    api: {
        invokeUrl: 'https://dvjfmnucag.execute-api.us-east-1.amazonaws.com/prod'
    }
};
